<?php include 'include/header.php' ?>
<?php include 'include/menu.php' ?>

    <section class="weekly-section">
        <div class="container bg-colored">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="parent-table">
                        <table class="table table-hover">
                            <thead>
                                <tr class="">
                                    <th scope="col">Weekly 1-18 weeks</th>
                                    <th scope="col">Existing</th>
                                    <th scope="col">Change</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Past Due</td>
                                    <td></td>
                                    <td>
                                    <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="weekdays-parent">
                                        <span>Week 1 </span>		<span>01-Oct-2024</span>
                                        </div>
                                    </td>
                                    <td><input type="text" name="" id=""></td>
                                    <td>
                                        <input type="text" name="" id="">
                                    </td>
                                </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php include 'include/footer.php' ?>