<?php $__env->startSection('css'); ?>
    <style>
        .select2-selection__arrow {
            background-image: unset !important;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class="users-data">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="all-user">
                        <table class="table table-hover table-bordered" id="myTable">
                            <thead>
                                <tr class="colored-table-row">
                                    <th class="highlighted toggle-header">id</th>
                                    <th class="toggleable toggle-header-department">DEPARTMENT</th>
                                    <th class="toggleable toggle-header-work-center">WORK CENTER </th>
                                    <th class="toggleable toggle-header-planning">PLANNING (QUEUE) </th>
                                </tr>
                            </thead>
                            <tbody id="entries-table-body">

                                <tr>
                                    <td class="vertical-text highlighted">
                                    </td>
                                    <td class="toggleable toggle-department">COMPRESSION</td>
                                    <td class="toggleable toggle-work-center">COM 1</td>
                                    <td class="toggleable toggle-planning">
                                        <div class="d-inline">
                                            <button class="btn btn-success">Edit</button>
                                            <button class="btn btn-danger">Delete</button>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td  class="vertical-text highlighted">
                                    </td>
                                    <td class="toggleable toggle-department">COMPRESSION</td>
                                    <td class="toggleable toggle-work-center">COM 1</td>
                                    <td class="toggleable toggle-planning">
                                        <div class="d-inline">
                                            <button class="btn btn-success">Edit</button>
                                            <button class="btn btn-danger">Delete</button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>






<?php $__env->startSection('js'); ?>
    <?php if($errors->any()): ?>
        <script>
            Swal.fire({
                title: 'Validation Errors!',
                html: `
                <ul style="text-align: left; margin-left: 40px;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            `,
                icon: 'error',
                confirmButtonText: 'OK'
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erp_app\resources\views/users.blade.php ENDPATH**/ ?>