<?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" name="id" id="data_id" value="<?php echo e($data->id); ?>">
    <tr>
        <td class="vertical-text highlighted">
        </td>
        <td class="toggleable toggle-department"><?php echo e($data->department); ?></td>
        <td class="toggleable toggle-work-center"><?php echo e($data->work_center_one->com ?? 'N/A'); ?></td>
        <?php if(Auth::user()->status_column == 1): ?>
            <td class="toggleable toggle-planning">
                <input type="text" name="planning" id="planning" value="<?php echo e($data->planning ?? ''); ?>"
                    data-id="<?php echo e($data->id); ?>" onkeyup="sendAjaxRequest('planning', this.value)">
            </td>
            <td class="toggleable">
                <select name="status" id="status"
                        data-id="<?php echo e($data->id); ?>"
                        onchange="sendAjaxRequest('status', this.value)">
                    <option value="" disabled selected>Select</option>
                    <option value="Running" <?php echo e($data->status == 'Running' ? 'selected' : ''); ?>>Running</option>
                    <option value="Pending Order" <?php echo e($data->status == 'Pending Order' ? 'selected' : ''); ?>>Pending Order</option>
                    <option value="Pause" <?php echo e($data->status == 'Pause' ? 'selected' : ''); ?>>Pause</option>
                    <option value="Closed" <?php echo e($data->status == 'Closed' ? 'selected' : ''); ?>>Closed</option>
                </select>
            </td>
            <td class="toggleable">
                <input type="text" name="job" id="job" value="<?php echo e($data->job ?? ''); ?>"
                    data-id="<?php echo e($data->id); ?>" onkeyup="sendAjaxRequest('job', this.value)">
            </td>
            <td class="toggleable">
                <input type="text" name="lot" id="lot" value="<?php echo e($data->lot ?? ''); ?>"
                    data-id="<?php echo e($data->id); ?>" onkeyup="sendAjaxRequest('lot', this.value)">
            </td>
        <?php else: ?>
            <td class="toggleable-1"><?php echo e($data->planning); ?></td>
            <td class="toggleable-1"><?php echo e($data->status); ?></td>
            <td class="toggleable-1"><?php echo e($data->job); ?></td>
            <td class="toggleable-1"><?php echo e($data->lot); ?></td>
        <?php endif; ?>
        <td class="toggleable">ID# <?php echo e($data->id); ?></td>
        <td class="toggleable"><?php echo e($data->part_number); ?></td>
        <td class="toggleable"><?php echo e($data->customer); ?></td>
        <td class="toggleable"><?php echo e($data->rev); ?></td>
        <td class="toggleable"><?php echo e($data->process); ?></td>
        <td  class="vertical-text highlighted">
        </td>

        <?php
            $weeksArr = $data->weeks_months;
            if ($weeksArr) {
                $sumWeeks1To6 = array_sum([$weeksArr['week_1'], $weeksArr['week_2'], $weeksArr['week_3'], $weeksArr['week_4'], $weeksArr['week_5'], $weeksArr['week_6']]);
                $sumWeeks7To12 = array_sum([$weeksArr['week_7'], $weeksArr['week_8'], $weeksArr['week_9'], $weeksArr['week_10'], $weeksArr['week_11'], $weeksArr['week_12']]);
            } else {
                $sumWeeks1To6 = $sumWeeks7To12 = 0;
            }

            $in_stock_finish = $data->in_stock_finish ?? 0;
            $wt_pc = $data->wt_pc ?? 0;

            if($sumWeeks1To6 != 0 && $sumWeeks7To12 != 0){
                $WT_RQ = max((($sumWeeks1To6 + $sumWeeks7To12) - $in_stock_finish) * $wt_pc, 0);
            }else{
                $WT_RQ = 0;
            }
        ?>

        <td class="toggleable-1"><?php echo e($sumWeeks1To6); ?></td>
        <td class="toggleable-1"><?php echo e($sumWeeks7To12); ?></td>
        <td class="toggleable-1"><?php echo e($sumWeeks1To6 + $sumWeeks7To12); ?></td>
        <td class="toggleable-1">
            <?php if(Auth::user()->stock_finished_column == 1): ?>
                <input type="number" step="any" name="in_stock_finish" id="in_stock_finish"
                    value="<?php echo e($data->in_stock_finish ?? ''); ?>" data-id="<?php echo e($data->id); ?>"
                    onkeyup="sendAjaxRequest('in_stock_finish', this.value)">
            <?php else: ?>
                <?php echo e($data->in_stock_finish ?? ''); ?>

            <?php endif; ?>
        </td>
        <?php
        $live_inventory_finish = \DB::table('inventory')->where('Part_No', $data->part_number)->whereIn('status', ['new', 'returned'])->where('location', '!=', 'WIP')->sum('container_qty');
        $live_inventory_wip = \DB::table('inventory')->where('Part_No', $data->part_number)->whereIn('status', ['new', 'returned'])->where('location', '=', 'WIP')->sum('container_qty');
        $in_stock_live = \DB::table('inventory')->where('Part_No', $data->part_number)->sum('weight');
        ?>
        <?php if(Auth::user()->role == 1): ?>
            <td class="toggleable-1">
                <input type="number" step="any" name="live_inventory_finish" id="live_inventory_finish"
                    value="<?php echo e($data->live_inventory_finish); ?>" data-id="<?php echo e($data->id); ?>"
                    onkeyup="sendAjaxRequest('live_inventory_finish', this.value)">
            </td>
            <td class="toggleable-1">
                <input type="number" step="any" name="live_inventory_wip" id="live_inventory_wip"
                    value="<?php echo e($data->live_inventory_wip); ?>" data-id="<?php echo e($data->id); ?>"
                    onkeyup="sendAjaxRequest('live_inventory_wip', this.value)">
            </td>
        <?php else: ?>
            <td class="toggleable-1"><?php echo e($data->live_inventory_finish); ?></td>
            <td class="toggleable-1"><?php echo e($data->live_inventory_wip); ?></td>
        <?php endif; ?>

        <?php if(Auth::user()->stock_finished_column == 1): ?>
            
            <td class="toggleable-1">
                <input type="number" step="any" name="in_process_outside" id="in_process_outside"
                    value="<?php echo e($data->in_process_outside ?? ''); ?>" data-id="<?php echo e($data->id); ?>"
                    onkeyup="sendAjaxRequest('in_process_outside', this.value)">
            </td>
            <td class="toggleable-1">
                <input type="text" name="raw_mat" id="raw_mat" value="<?php echo e($data->raw_mat ?? ''); ?>"
                    data-id="<?php echo e($data->id); ?>" onkeyup="sendAjaxRequest('raw_mat', this.value)">
            </td>
        <?php else: ?>
            <td class="toggleable-1"><?php echo e($data->in_process_outside); ?></td>
            <td class="toggleable-1"><?php echo e($data->raw_mat); ?></td>
        <?php endif; ?>
        <?php if(Auth::user()->role == 1): ?>
            <td class="toggleable-1">
                <input type="number" step="any" name="in_stock_live" id="in_stock_live"
                    value="<?php echo e($data->in_stock_live); ?>" data-id="<?php echo e($data->id); ?>"
                    onkeyup="sendAjaxRequest('in_stock_live', this.value)">
            </td>
        <?php else: ?>
            <td class="toggleable-1"><?php echo e($data->in_stock_live); ?></td>
        <?php endif; ?>
        <td class="toggleable-1"><?php echo e($data->wt_pc); ?></td>
        <td class="toggleable-1"><?php echo e($data->material); ?></td>
        <td class="toggleable-1"><?php echo e((($data->wt_pc / 1000) * $sumWeeks1To6)); ?></td>
        <td class="toggleable-1"><?php echo e($data->safety); ?></td>
        <td class="toggleable-1"><?php echo e($data->min_ship); ?></td>
        <td class="toggleable-1"><?php echo e($data->order_notes); ?></td>
        <td class="toggleable-1"><?php echo e($data->part_notes); ?></td>
        <td  class="vertical-text highlighted">
        </td>
        <td class="toggleable-2"><?php echo e($data->weeks_months->past_due ?? ''); ?></td>
        <?php for($week = 1; $week <= 16; $week++): ?>
            <?php $weekKey = 'week_' . $week; ?>
            <td class="toggleable-2 shipment_date" data-week-change='week_<?php echo e($week); ?>'>
                <?php echo e($data->weeks_months->$weekKey ?? ''); ?>

            </td>
        <?php endfor; ?>
        <?php for($month = 5; $month <= 12; $month++): ?>
            <?php $monthKey = 'month_' . $month; ?>
            <td class="toggleable-2 shipment_date" data-week-change='month_<?php echo e($month); ?>'>
                <?php echo e($data->weeks_months->$monthKey ?? ''); ?>

            </td>
        <?php endfor; ?>
        <td class="toggleable-2"><?php echo e($data->future_raw); ?></td>
        <td class="toggleable-2">$<?php echo e($data->price); ?></td>
        <td class="toggleable-2"><?php echo e($data->notes); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\erp_app\resources\views/partials/entries.blade.php ENDPATH**/ ?>