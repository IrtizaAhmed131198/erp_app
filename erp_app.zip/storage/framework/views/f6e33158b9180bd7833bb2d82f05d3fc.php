<?php $__env->startSection('css'); ?>
    <style>
        .select2-selection__arrow {
            background-image: unset !important;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class="weekly-section data-center">
        <div class="container bg-colored">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="parent-table">
                        <form action="<?php echo e(route('post_data_center')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <table class="table table-hover table-bordered">
                                <thead>
                                </thead>
                                <tbody>
                                    <tr class="">
                                        <td scope="col" colspan="2"><strong>Part Number Input</strong></td>
                                        <!-- <td scope="col">

                                                                                                </td> -->
                                    </tr>
                                    <tr>
                                        <td>Part Number</td>
                                        <td>
                                            <select class="form-select js-select21" name="part_number"
                                                aria-label="Default select example">
                                                <option selected disabled>Select Part Number</option>
                                                <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->Part_Number); ?>"
                                                        <?php echo e(old('part_number') == $item->Part_Number ? 'selected' : ''); ?>>
                                                        <?php echo e($item->Part_Number); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Customer</td>
                                        <td>
                                            <select class="form-select js-select21" name="customer"
                                                aria-label="Default select example">
                                                <option selected disabled>Select Customer</option>
                                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->CustomerName); ?>"
                                                        <?php echo e(old('customer') == $item->CustomerName ? 'selected' : ''); ?>>
                                                        <?php echo e($item->CustomerName); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Revision</td>
                                        <td>
                                            <input type="text" name="revision" value="<?php echo e(old('revision')); ?>"
                                                id="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>ID</td>
                                        <td>
                                            <input type="text" name="ids" value="<?php echo e(old('ids')); ?>" id="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Process</td>
                                        <td>
                                            <input type="text" name="process" value="<?php echo e(old('process')); ?>"
                                                id="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Department</td>
                                        <td>
                                            <select class="js-select2 select2-hidden-accessible" name="department"
                                                tabindex="-1" aria-hidden="true">
                                                <option selected disabled>Select DEPARTMENT</option>
                                                <option value="COMPRESSION"
                                                    <?php echo e(old('department') == 'COMPRESSION' ? 'selected' : ''); ?>>COMPRESSION
                                                </option>
                                                <option value="EXTENSION"
                                                    <?php echo e(old('department') == 'EXTENSION' ? 'selected' : ''); ?>>EXTENSION
                                                </option>
                                                <option value="MULTI SLIDE"
                                                    <?php echo e(old('department') == 'MULTI SLIDE' ? 'selected' : ''); ?>>MULTI SLIDE
                                                </option>
                                                <option value="PRESS DEPT"
                                                    <?php echo e(old('department') == 'PRESS DEPT' ? 'selected' : ''); ?>>PRESS DEPT
                                                </option>
                                                <option value="PURCHASED"
                                                    <?php echo e(old('department') == 'PURCHASED' ? 'selected' : ''); ?>>PURCHASED
                                                </option>
                                                <option value="SLIDES"
                                                    <?php echo e(old('department') == 'SLIDES' ? 'selected' : ''); ?>>SLIDES</option>
                                                <option value="STOCK"
                                                    <?php echo e(old('department') == 'STOCK' ? 'selected' : ''); ?>>STOCK</option>
                                                <option value="TORSION"
                                                    <?php echo e(old('department') == 'TORSION' ? 'selected' : ''); ?>>TORSION</option>
                                                <option value="WIREFORM"
                                                    <?php echo e(old('department') == 'WIREFORM' ? 'selected' : ''); ?>>WIREFORM
                                                </option>
                                            </select>
                                        </td>
                                    </tr>
                                    <?php for($i = 1; $i <= 7; $i++): ?>
                                        <tr>
                                            <td>Work Centre <?php echo e($i); ?></td>
                                            <td>
                                                <select class="form-select" name="work_centre_<?php echo e($i); ?>"
                                                    aria-label="Default select example">
                                                    <option selected></option>
                                                    <option value="COM 1"
                                                        <?php echo e(old('work_centre_' . $i) == 'COM 1' ? 'selected' : ''); ?>>COM 1
                                                    </option>
                                                    <option value="COM 2"
                                                        <?php echo e(old('work_centre_' . $i) == 'COM 2' ? 'selected' : ''); ?>>COM 2
                                                    </option>
                                                    <option value="COM 3"
                                                        <?php echo e(old('work_centre_' . $i) == 'COM 3' ? 'selected' : ''); ?>>COM 3
                                                    </option>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endfor; ?>
                                    <?php for($i = 1; $i <= 4; $i++): ?>
                                        <tr>
                                            <td>Outside Processing <?php echo e($i); ?></td>
                                            <td>
                                                <div class="parent-inputs">
                                                    <select class="form-select"
                                                        name="outside_processing_<?php echo e($i); ?>"
                                                        aria-label="Default select example">
                                                        <option selected></option>
                                                        <option value="OUT 1"
                                                            <?php echo e(old('outside_processing_' . $i) == 'OUT 1' ? 'selected' : ''); ?>>
                                                            OUT 1</option>
                                                        <option value="OUT 2"
                                                            <?php echo e(old('outside_processing_' . $i) == 'OUT 2' ? 'selected' : ''); ?>>
                                                            OUT 2</option>
                                                        <option value="OUT 3"
                                                            <?php echo e(old('outside_processing_' . $i) == 'OUT 3' ? 'selected' : ''); ?>>
                                                            OUT 3</option>
                                                    </select>
                                                    <input type="text"
                                                        name="outside_processing_text_<?php echo e($i); ?>"
                                                        value="<?php echo e(old('outside_processing_text_' . $i)); ?>" id="">
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endfor; ?>
                                    <tr>
                                        <td>Material</td>
                                        <td>
                                            <select class="form-select js-select21" name="material"
                                                aria-label="Default select example">
                                                <option selected disabled>Select Material</option>
                                                <?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->Package); ?>"
                                                        <?php echo e(old('customer') == $item->Package ? 'selected' : ''); ?>>
                                                        <?php echo e($item->Package); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Pc Weight</td>
                                        <td>
                                            <input type="number" step="any" name="pc_weight"
                                                value="<?php echo e(old('pc_weight')); ?>" id="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Safety Stock</td>
                                        <td>
                                            <input type="number" step="any" name="safety_stock"
                                                value="<?php echo e(old('safety_stock')); ?>" id="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>MOQ</td>
                                        <td>
                                            <input type="number" step="any" name="moq" value="<?php echo e(old('moq')); ?>"
                                                id="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Order Notes</td>
                                        <td>
                                            <textarea name="order_notes" id=""><?php echo e(old('order_notes')); ?></textarea>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Part Notes</td>
                                        <td>
                                            <textarea name="part_notes" id=""><?php echo e(old('part_notes')); ?></textarea>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Future Raw</td>
                                        <td>
                                            <input type="text" name="future_raw" value="<?php echo e(old('future_raw')); ?>"
                                                id="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Price</td>
                                        <td>
                                            <input type="number" step="any" name="price" value="<?php echo e(old('price')); ?>"
                                                id="">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>REV</td>
                                        <td>
                                            <input type="text" name="rev" id="rev" value="<?php echo e(old('rev')); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Wt Req'd</td>
                                        <td>
                                            <input type="number" step="any" name="wet_reqd" id="wet_reqd" value="<?php echo e(old('wet_reqd')); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Safety</td>
                                        <td>
                                            <input type="text" name="safety" id="safety" value="<?php echo e(old('safety')); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Minship</td>
                                        <td>
                                            <input type="number" name="min_ship" id="min_ship" value="<?php echo e(old('min_ship')); ?>">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="btn-custom-btn text-ceneter mt-5">
                                <button type="submit" class="btn custom-btn">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php if($errors->any()): ?>
        <script>
            Swal.fire({
                title: 'Validation Errors!',
                html: `
                <ul style="text-align: left; margin-left: 40px;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            `,
                icon: 'error',
                confirmButtonText: 'OK'
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erp_app\resources\views/data-center.blade.php ENDPATH**/ ?>