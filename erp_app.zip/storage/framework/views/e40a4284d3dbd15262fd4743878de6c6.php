<?php $__env->startSection('css'); ?>
<style>
    div#collapseTwo table {
        width: 30%;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="weekly-section">
        <div class="container bg-colored">
            <div class="row align-items-center">
                <div class="col-lg-3">
                    <div class="parent-filter">
                        <select class="js-select2" id="partNumberSelect">
                            <option selected disabled>Select Part Number</option>
                            <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->Part_Number); ?>"
                                    <?php echo e(old('part_number') == $item->Part_Number ? 'selected' : ''); ?>>
                                    <?php echo e($item->Part_Number); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="part_no" id="part_no" value="">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="d-flex justify-content-start mb-3 custom-data">
                        <button class="btn btn-primary me-2" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            Create Order
                        </button>
                        <button class="btn btn-primary me-2" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            Add Production
                        </button>
                        <button class="btn btn-primary" id="btn-add-shipment" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            Add Shipment
                        </button>
                    </div>

                    <div class="accordion" id="mainAccordion">
                        <!-- First Collapsible Content -->
                        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#mainAccordion">
                            <div class="accordion-body">
                                <div class="parent-table">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr class="">
                                                <th scope="col">Weekly 1-18 weeks</th>
                                                <th scope="col">Add amount of shipment</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php for($week = 1; $week <= 16; $week++): ?>
                                                <tr>
                                                    <td>
                                                        <div class='weekdays-parent'>
                                                            <span>Week <?php echo e($week); ?> </span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <input type='number' class='shipment-input' data-week='week_<?php echo e($week); ?>' name='shipment[week_<?php echo e($week); ?>]' id='week_<?php echo e($week); ?>'>
                                                    </td>
                                                </tr>
                                            <?php endfor; ?>

                                            <?php for($month = 5; $month <= 12; $month++): ?>
                                                <tr>
                                                    <td>
                                                        <div class='weekdays-parent'>
                                                            <span>Month <?php echo e($month); ?> </span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <input type='number' class='shipment-input' data-week='month_<?php echo e($month); ?>' name='shipment[month_<?php echo e($month); ?>]' id='month_<?php echo e($month); ?>'>
                                                    </td>
                                                </tr>
                                            <?php endfor; ?>

                                        </tbody>
                                    </table>
                                    <div class="btn-custom-btn text-ceneter mt-5">
                                        <button type="button" id="create-order" class="btn custom-btn">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Second Collapsible Content -->
                        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#mainAccordion">
                            <div class="accordion-body">
                                <div class="parent-table">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr class="">
                                                <th scope="col">Existing Amount</th>
                                                <td> <input type="text" name="existing_amount" id="existing_amount" readonly></td>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Add Production</td>
                                                <td> <input type="text" name="add_production" id="add_production" min="0"></td>

                                            </tr>
                                            <tr>
                                                <td>New Total</td>

                                                <td><input type="text" name="new_total" id="new_total" readonly></td>

                                            </tr>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Third Collapsible Content -->
                        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#mainAccordion">
                            <div class="accordion-body">
                                <div class="parent-table">
                                    <div class="add-shipment-amount">
                                        <input type="number" name="" id="" placeholder="Add Shipment Amount">
                                        <button class="btn btn-primary">Add</button>
                                    </div>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr class="">
                                                <th scope="col">Weekly 1-18 weeks</th>
                                                <th scope="col">Existing</th>
                                                <th scope="col">Change</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Past Due</td>
                                                <td id="past_due_val"></td>
                                                <td>
                                                <input type="text" name="past_due" id="past_due">
                                                <button type="button" id="change_past_due" style="display: none;"><i class="fa-regular fa-pen-to-square"></i></button>
                                                </td>
                                            </tr>
                                            
                                            <?php
                                            $datesArray = [];

                                            // Calculate the start date of week 16
                                            $today = date('Y-m-d');
                                            $dayOfWeek = date('w', strtotime($today)); // 0 (Sunday) to 6 (Saturday)
                                            $mondayOfWeek = date('Y-m-d', strtotime('-'.$dayOfWeek.' days', strtotime($today)));
                                            $week16StartDate = date('Y-m-d', strtotime('+15 weeks', strtotime($mondayOfWeek)));

                                            // Calculate the end date of week 16
                                            $week16EndDate = date('Y-m-d', strtotime('+6 days', strtotime($week16StartDate)));

                                            // Calculate the start date of month 5 (the day after week 16 ends)
                                            $month5StartDate = date('Y-m-d', strtotime('+1 day', strtotime($week16EndDate)));

                                            ?>

                                            <?php for($week = 1; $week <= 16; $week++): ?>
                                                <?php
                                                    $startOfWeek = date('Y-m-d', strtotime('+'.(($week - 1) * 7).' days', strtotime($mondayOfWeek)));
                                                    $endOfWeek = date('Y-m-d', strtotime('+6 days', strtotime($startOfWeek)));
                                                    $datesArray["week_$week"] = $startOfWeek;
                                                ?>
                                                <tr>
                                                    <td>
                                                        <div class='weekdays-parent'>
                                                            <span>Week <?php echo e($week); ?> (<?php echo e($startOfWeek); ?> - <?php echo e($endOfWeek); ?>)</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <input type='number' class='edit_existing' data-edit-week-change='week_<?php echo e($week); ?>' name='edit_existing[week_<?php echo e($week); ?>]' id='edit_week_<?php echo e($week); ?>'>
                                                    </td>
                                                    <td>
                                                        <input type="number" class='change-amount' data-week-change='week_<?php echo e($week); ?>' name="change_amount[week_<?php echo e($week); ?>]" id="change_week_<?php echo e($week); ?>">
                                                    </td>
                                                </tr>
                                            <?php endfor; ?>

                                            <?php for($month = 5; $month <= 12; $month++): ?>
                                                <tr>
                                                    <td>
                                                        <div class='weekdays-parent'>
                                                            <span>Month <?php echo e($month); ?> (<?php echo e($month5StartDate); ?> - <?php echo e(date('Y-m-d', strtotime('+30 days', strtotime($month5StartDate)))); ?>)</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <input type='number' class='edit_existing' data-edit-week-change='month_<?php echo e($month); ?>' name='edit_existing[month_<?php echo e($month); ?>]' id='edit_month_<?php echo e($month); ?>'>
                                                    </td>
                                                    <td>
                                                        <input type="number" class='change-amount' data-week-change='month_<?php echo e($month); ?>' name="change_amount[month_<?php echo e($month); ?>]" id="change_month_<?php echo e($month); ?>">
                                                    </td>
                                                </tr>
                                                <?php
                                                    $datesArray["month_$month"] = $month5StartDate;
                                                    $month5StartDate = date('Y-m-d', strtotime('+31 days', strtotime($month5StartDate)));
                                                ?>
                                            <?php endfor; ?>
                                            


                                        </tbody>
                                    </table>
                                    <div class="btn-custom-btn text-ceneter mt-5">
                                        <button type="button" id="add-shipment" class="btn custom-btn">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('#btn-add-shipment').on('click', function() {
            console.log(123);
            let partNumber = $('#part_no').val();
            $.ajax({
                url: "<?php echo e(route('get_weeks')); ?>", // Replace with your backend route
                method: 'POST',
                data: {
                    part_number: partNumber
                },
                headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
                success: function(response) {
                    if (response.data) {
                        let weeksData = {};
                        let data = response.data;
                        let temp = <?php echo json_encode($datesArray, 15, 512) ?>;
                        let temp1 = <?php echo json_encode($datesArray, 15, 512) ?>;
                        // Iterate through the response data object
                        for (let key in data) {
                            let value = data[key];

                            $(`#edit_${key}`).val(value);
                            weeksData[`${key}`] = value;
                            temp[`${key}`] = value;
                            temp[`${key}_date`] = temp1[`${key}`];
                        }

                        // $('#past_due').val(response.in_stock_finish);



                        // $('.change-amount').each(function () {
                        //     const weekKey = $(this).data('week-change');
                        //     const weekValue = $(this).val();
                        //     console.log(weekKey, weekValue);
                        //     weeksData[`${weekKey}`] = weekValue;
                        // });

                        $.ajax({
                            url: "<?php echo e(route('update_past_due')); ?>",
                            method: 'POST',
                            data: {
                                weeks: weeksData,
                                part_number: partNumber,
                                current_date: "<?php echo e(date('Y-m-d')); ?>",
                                dates_array: temp
                            },
                            headers: { 'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content') },
                            success: function (response) {
                                console.log('Total Past Value:', response.totalPastValue);
                                // alert(response.message);
                                let data = response.data;
                                $('#past_due_val').text(response.past_due_val);
                                // Iterate through the response data object
                                for (let key in data) {
                                    let value = data[key];

                                    $(`#edit_${key}`).val(value);
                                }
                            },
                            error: function (xhr) {
                                console.error("Error updating shipment: ", xhr.responseText);
                            }
                        });
                    } else {
                        console.error("No data found in the response");
                    }
                },
                error: function(xhr) {
                    console.error("Error updating shipment: ", xhr.responseText);
                }
            });
        });

        $(document).ready(function() {
            $('.btn[data-bs-toggle="collapse"]').prop('disabled', true);

            $('#partNumberSelect').on('change', function() {
                const selectedPartNumber = $(this).val(); // Get selected part number
                console.log("Selected Part Number: ", selectedPartNumber);

                $('#part_no').val(selectedPartNumber);

                $('.accordion-collapse').collapse('hide');

                // Check if a valid part number is selected
                if (selectedPartNumber) {

                    $.ajax({
                        url: "<?php echo e(route('get_part_no_detail')); ?>", // Replace with your route URL
                        method: 'GET',
                        data: { part_number: selectedPartNumber }, // Send part number as data
                        success: function(response) {
                            if (response.existing_amount) {
                                $('input[name="existing_amount"]').val(response.existing_amount);
                                $('.btn[data-bs-toggle="collapse"]').prop('disabled', false);
                            } else {
                                Swal.fire({
                                    icon: 'info',
                                    title: 'No Data Found',
                                    text: response.message ?? 'No entry found for the provided part number.',
                                });
                                $('.btn[data-bs-toggle="collapse"]').prop('disabled', true);
                            }
                        },
                        error: function(xhr) {
                            console.error("Error fetching data: ", xhr.responseText);
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Failed to fetch the existing amount. Please try again.',
                            });
                        }
                    });
                } else {
                    $('.btn[data-bs-toggle="collapse"]').prop('disabled', true);
                }
            });

            $('#add_production').on('input', function() {
                const existingAmount = parseFloat($('#existing_amount').val()) || 0;
                const addProduction = parseFloat($(this).val()) || 0;

                // Calculate new total
                const newTotal = existingAmount + addProduction;

                let part_no = $('#part_no').val();

                // Send data to server via AJAX
                $.ajax({
                    url: "<?php echo e(route('update_production_total')); ?>", // Replace with your backend route
                    method: 'POST',
                    data: {
                        existing_amount: existingAmount,
                        add_production: addProduction,
                        new_total: newTotal,
                        part_no: part_no,
                        _token: "<?php echo e(csrf_token()); ?>" // CSRF Token for security
                    },
                    success: function(response) {
                        $('#new_total').val(response.new_total);
                    },
                    error: function(xhr) {
                        console.error("Error updating total: ", xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'Update Failed',
                            text: 'An error occurred while updating the total. Please try again.',
                        });
                    }
                });
            });

            $('#create-order').on('click', function() {
                let weeksData = {};

                $('.shipment-input').each(function() {
                    const weekKey = $(this).data('week');
                    const weekValue = $(this).val();
                    weeksData[`${weekKey}`] = weekValue;
                });

                let partNumber = $('#part_no').val();

                // Optionally, send updated data to the server via AJAX
                $.ajax({
                    url: "<?php echo e(route('create_order')); ?>", // Replace with your backend route
                    method: 'POST',
                    data: {
                        weeks: weeksData,
                        part_number: partNumber
                    },
                    headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
                    success: function(response) {
                        if(response.error){

                            Swal.fire({
                                icon: 'error',
                                title: 'Shipment Order',
                                text: response.message,
                            });

                        }else{
                            Swal.fire({
                                icon: 'success',
                                title: 'Shipment Order Created',
                                text: response.message ?? 'Shipment Order Created.',
                            });
                        }
                    },
                    error: function(xhr) {
                        console.error("Error updating shipment: ", xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'Shipment Order Failed',
                            text: 'An error occurred while updating the shipment amount. Please try again.',
                        });
                    }
                });
            });



            $('#add-shipment').on('click', function() {
                let weeksData = {};

                $('.change-amount').each(function() {
                    const weekKey = $(this).data('week-change');
                    const weekValue = $(this).val();
                    weeksData[`${weekKey}`] = weekValue;
                });

                let partNumber = $('#part_no').val();

                // Optionally, send updated data to the server via AJAX
                $.ajax({
                    url: "<?php echo e(route('add_shipment')); ?>", // Replace with your backend route
                    method: 'POST',
                    data: {
                        weeks: weeksData,
                        part_number: partNumber
                    },
                    headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
                    success: function(response) {
                        if(response.error){

                            Swal.fire({
                                icon: 'error',
                                title: 'Shipment Order',
                                text: response.message,
                            });

                        }else{
                            Swal.fire({
                                icon: 'success',
                                title: 'Shipment Order Change',
                                text: response.message ?? 'Shipment Order Change.',
                            });

                            let data = response.data;
                            // Iterate through the response data object
                            for (let key in data) {
                                let value = data[key];

                                $(`#edit_${key}`).val(value);
                            }
                        }
                    },
                    error: function(xhr) {
                        console.error("Error updating shipment: ", xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'Shipment Order Failed',
                            text: 'An error occurred while updating the shipment amount. Please try again.',
                        });
                    }
                });
            });

            $(document).on('click', '.add-shipment-amount .btn', function () {
                let partNumber = $('#part_no').val();
                let shippedAmount = parseFloat($('.add-shipment-amount input').val()); // Get the shipment amount entered
                if (isNaN(shippedAmount) || shippedAmount <= 0) {
                    alert("Please enter a valid shipment amount.");
                    return;
                }

                // Collect values from input fields with names starting with 'edit_existing'
                let fieldsData = [];
                $("input[name^='edit_existing']").each(function () {
                    let $field = $(this);
                    let currentValue = parseFloat($field.val()) || 0; // Get the current value of the field (default to 0)
                    let weekKey = $(this).data('edit-week-change');
                    fieldsData.push({ weekKey: weekKey, value: currentValue });
                });

                // Distribute shipped amount among the fields
                shippedAmount = distributeShipmentAmount(fieldsData, shippedAmount);
                console.log(fieldsData);

                // If any amount remains undistributed, alert the user
                if (shippedAmount > 0) {
                    alert("Remaining shipment amount: " + shippedAmount);
                } else {
                    alert("Shipment amount distributed successfully.");

                    // Send data to server-side script for saving in database
                    $.ajax({
                        url: "<?php echo e(route('save_shipment_data')); ?>", // Endpoint to handle data storage
                        method: 'POST',
                        data: { shipmentData: fieldsData, part_number: partNumber },
                        headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
                        success: function(response) {
                            console.log('Data saved successfully:', response);
                            let data = response.data;
                            // Iterate through the response data object
                            for (let key in data) {
                                let value = data[key];

                                $(`#edit_${key}`).val(value);
                            }
                        },
                        error: function(error) {
                            console.error('Error saving data:', error);
                        }
                    });
                }
            });

            // Function to distribute shipment amount among fields
            function distributeShipmentAmount(fieldsData, shippedAmount) {
                fieldsData.forEach((field, index) => {
                    if (shippedAmount <= 0) return;

                    if (field.value > 0) {
                        if (field.value >= shippedAmount) {
                            field.value -= shippedAmount; // Deduct shippedAmount from the current field's value
                            shippedAmount = 0; // Fully distributed
                        } else {
                            shippedAmount -= field.value; // Deduct the field's value from shippedAmount
                            field.value = 0; // Zero out the current field's value
                        }
                    }
                });
                return shippedAmount;
            }

            $('#past_due').on('keyup', function() {
                $('#change_past_due').show();
            });


            $('#change_past_due').on('click', function() {
                let value = $('#past_due').val();
                let partNumber = $('#part_no').val();

                $.ajax({
                    url: "<?php echo e(route('change_past_due')); ?>", // Endpoint to handle data storage
                    method: 'POST',
                    data: { past_due: value, part_number: partNumber },
                    headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
                    success: function(response) {
                        // console.log('Data saved successfully:', response);
                        $('#past_due_val').text(response.past_due ?? '');
                    },
                    error: function(error) {
                        console.error('Error saving data:', error);
                    }
                });
            });

            $(document).on('input', '.change-amount', function () {
                const $input = $(this);
                const weekOrMonthId = $input.data('week-change');
                const $button = $(`#change_${weekOrMonthId}_btn`);

                // If value is not empty, show the button; otherwise, hide it
                if ($input.val() !== '') {
                    if ($button.length === 0) {
                        // If button doesn't exist, create and append it
                        const buttonHtml = `<button id="change_${weekOrMonthId}_btn" class="update-btn" data-week-month="${weekOrMonthId}"><i class="fa-regular fa-pen-to-square"></i></button>`;
                        $input.after(buttonHtml);
                    }
                } else {
                    // Remove button if input is empty
                    $button.remove();
                }
            });

            $(document).on('click', '.update-btn', function () {
                let partNumber = $('#part_no').val();
                const $button = $(this);
                const weekOrMonthId = $button.data('week-month');
                const $input = $(`[data-week-change="${weekOrMonthId}"]`);
                const value = $input.val();

                if (value) {
                    $.ajax({
                        url: "<?php echo e(route('update_week_or_month')); ?>", // Replace with your actual route
                        method: 'POST',
                        data: {
                            id: weekOrMonthId,
                            value: value,
                            part_number: partNumber
                        },
                        headers: { 'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content') },
                        success: function (response) {
                            const $editInput = $(`[data-edit-week-change="${weekOrMonthId}"]`);
                            if ($editInput.length > 0) {
                                $editInput.val(value); // Set the value from the input
                            }
                            // alert('Value updated successfully');
                            $button.remove(); // Remove the button on success
                        },
                        error: function (error) {
                            console.error('Error updating value:', error);
                            alert('Failed to update value');
                        }
                    });
                }
            });


        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erp_app\resources\views/calender.blade.php ENDPATH**/ ?>