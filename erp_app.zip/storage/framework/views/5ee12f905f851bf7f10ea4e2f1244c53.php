<?php $__env->startSection('content'); ?>
    <section class="weekly-section">
        <div class="container-xl px-4 mt-4">
            <!-- Account page navigation-->
            <nav class="nav nav-borders">
                <a class="nav-link active ms-0" href="<?php echo e(route('users.index')); ?>">Users</a>
                <a class="nav-link" href="<?php echo e(route('notifications')); ?>">Notifications</a>
            </nav>
            <hr class="mt-0 mb-4">
            <form action="<?php echo e(route('users.update')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                <div class="row">
                    <div class="col-xl-4">
                        <!-- Profile picture card-->
                        <div class="card mb-4 mb-xl-0">
                            <div class="card-header highlighted">Profile Picture</div>
                            <div class="card-body text-center">
                                <!-- Profile picture image-->
                                <img class="img-account-profile rounded-circle mb-2 preview_image img-fluid"
                                    src="<?php echo e(asset('images/profile-1.png')); ?>" alt="">
                                <input id="user_profile_image_path" type="file" name="user_img" class="d-none"
                                    accept="image/*">
                                <!-- Custom file label and file name display -->
                                <label for="user_profile_image_path" class="file-label">Upload Image</label>
                                <span id="fileName" class="file-name">No file chosen</span>
                                <!-- Profile picture help block-->
                                
                                <!-- Profile picture upload button-->
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-8">
                        <!-- Account details card-->
                        <div class="card mb-4">
                            <div class="card-header highlighted">Account Details</div>
                            <div class="card-body">

                                <!-- Form Group (username)-->

                                <!-- Form Row-->
                                

                                <!-- Form Row-->
                                <div class="row gx-3 mb-3">
                                    <!-- Form Group (first name)-->
                                    <div class="col-md-6">
                                        <label class="mb-1" for="inputFirstName">name</label>
                                        <input class="form-control" id="inputFirstName" type="text" name="name"
                                            placeholder="Enter your first name" value="<?php echo e($data->name); ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="mb-1" for="inputEmailAddress">Email address</label>
                                        <input class="form-control" id="inputEmailAddress" type="email" name="email"
                                            placeholder="Enter your email address" value="<?php echo e($data->email); ?>" required>
                                    </div>
                                    <!-- Form Group (last name)-->
                                    
                                </div>
                                <!-- Form Row        -->
                                <div class="row gx-3 mb-3">
                                    <!-- Form Group (organization name)-->
                                    <div class="col-md-6">
                                        <label class="mb-1" for="inputOrgName">Department</label>
                                        <select class="custom-select form-control" name="department" required>
                                            <option selected disabled>Select Department</option>
                                            <option value="EXTENSION"
                                                <?php echo e(old('department') == 'EXTENSION' || (isset($data->department) && $data->department == 'EXTENSION') ? 'selected' : ''); ?>>
                                                EXTENSION</option>
                                            <option value="MULTI SLIDE"
                                                <?php echo e(old('department') == 'MULTI SLIDE' || (isset($data->department) && $data->department == 'MULTI SLIDE') ? 'selected' : ''); ?>>
                                                MULTI SLIDE</option>
                                            <option value="PRESS DEPT"
                                                <?php echo e(old('department') == 'PRESS DEPT' || (isset($data->department) && $data->department == 'PRESS DEPT') ? 'selected' : ''); ?>>
                                                PRESS DEPT</option>
                                            <option value="PURCHASED"
                                                <?php echo e(old('department') == 'PURCHASED' || (isset($data->department) && $data->department == 'PURCHASED') ? 'selected' : ''); ?>>
                                                PURCHASED</option>
                                            <option value="SLIDES"
                                                <?php echo e(old('department') == 'SLIDES' || (isset($data->department) && $data->department == 'SLIDES') ? 'selected' : ''); ?>>
                                                SLIDES</option>
                                            <option value="STOCK"
                                                <?php echo e(old('department') == 'STOCK' || (isset($data->department) && $data->department == 'STOCK') ? 'selected' : ''); ?>>
                                                STOCK</option>
                                            <option value="TORSION"
                                                <?php echo e(old('department') == 'TORSION' || (isset($data->department) && $data->department == 'TORSION') ? 'selected' : ''); ?>>
                                                TORSION</option>
                                            <option value="WIREFORM"
                                                <?php echo e(old('department') == 'WIREFORM' || (isset($data->department) && $data->department == 'WIREFORM') ? 'selected' : ''); ?>>
                                                WIREFORM</option>
                                        </select>
                                    </div>
                                    <!-- Form Group (phone number)-->
                                    <div class="col-md-6">
                                        <label class="mb-1" for="inputPhone">Phone number</label>
                                        <input class="form-control" id="inputPhone" type="tel" name="phone"
                                            placeholder="Enter your phone number" value="<?php echo e($data->phone); ?>" required>
                                    </div>
                                </div>
                                <!-- Form Group (email address)-->
                                <div class="row gx-3 mb-3">

                                    <div class="col-md-6">
                                        <label class="mb-1" for="inputpassword">Password</label>
                                        <input class="form-control" id="inputpassword" type="text" name="password"
                                            placeholder="Enter your password" value="">
                                    </div>
                                </div>

                                <div class="card-body border-top px-9 py-9">
                                    <h5>
                                        User Permissions
                                    </h5>
                                    <!--begin::Option-->
                                    <label class="form-check form-check-custom form-check-solid align-items-start">
                                        <!--begin::Input-->
                                        <input class="form-check-input me-3" type="checkbox" name="status_column" <?php echo e($data->status_column == 1 ? 'checked' : ''); ?>

                                            value="1">
                                        <!--end::Input-->

                                        <!--begin::Label-->
                                        <span class="form-check-label d-flex flex-column align-items-start">
                                            <span class="fs-6 mb-0">Status Coulmns</span>
                                        </span>
                                        <!--end::Label-->
                                    </label>
                                    <!--end::Option-->

                                    <!--begin::Option-->
                                    <div class="separator separator-dashed my-6"></div>
                                    <!--end::Option-->
                                    <!--begin::Option-->
                                    <label class="form-check form-check-custom form-check-solid align-items-start">
                                        <!--begin::Input-->
                                        <input class="form-check-input me-3" type="checkbox" name="stock_finished_column" value="1" <?php echo e($data->stock_finished_column == 1 ? 'checked' : ''); ?>>
                                        <!--end::Input-->

                                        <!--begin::Label-->
                                        <span class="form-check-label d-flex flex-column align-items-start">
                                            <span class="fs-6 mb-0">Stock Finished Column</span>
                                            
                                        </span>
                                        <!--end::Label-->
                                    </label>
                                    <!--end::Option-->

                                    <!--begin::Option-->
                                    <div class="separator separator-dashed my-6"></div>
                                    <!--end::Option-->
                                    <!--begin::Option-->
                                    <label class="form-check form-check-custom form-check-solid align-items-start">
                                        <!--begin::Input-->
                                        <input class="form-check-input me-3" type="checkbox" name="part_number_column"
                                            value="1" <?php echo e($data->part_number_column == 1 ? 'checked' : ''); ?>>
                                        <!--end::Input-->

                                        <!--begin::Label-->
                                        <span class="form-check-label d-flex flex-column align-items-start">
                                            <span class="fs-6 mb-0">Part Number Section</span>
                                            
                                        </span>
                                        <!--end::Label-->
                                    </label>
                                    <!--end::Option-->

                                    <!--begin::Option-->
                                    <div class="separator separator-dashed my-6"></div>
                                    <!--end::Option-->
                                    <!--begin::Option-->
                                    <label class="form-check form-check-custom form-check-solid align-items-start">
                                        <!--begin::Input-->
                                        <input class="form-check-input me-3" type="checkbox"
                                            name="calendar_column" value="0" <?php echo e($data->calendar_column == 1 ? 'checked' : ''); ?>>
                                        <!--end::Input-->

                                        <!--begin::Label-->
                                        <span class="form-check-label d-flex flex-column align-items-start">
                                            <span class="fs-6 mb-0">Calendar Section</span>
                                            
                                        </span>
                                        <!--end::Label-->
                                    </label>
                                    <!--end::Option-->



                                </div>

                                <button class="btn btn-primary" type="submit">Save changes</button>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    document.getElementById('user_profile_image_path').addEventListener('change', function() {
        const file = this.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            document.querySelector('.preview_image').src = e.target.result;
        };
        reader.readAsDataURL(file);

        // Update file name display
        document.getElementById('fileName').textContent = file.name;
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\erp_app\resources\views/users/edit.blade.php ENDPATH**/ ?>